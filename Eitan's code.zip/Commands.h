#ifndef SMASH_COMMAND_H_
#define SMASH_COMMAND_H_
#include <vector>
#include "iostream"
#include <fcntl.h>
#include <string>

#define COMMAND_ARGS_MAX_LENGTH (200)
#define COMMAND_MAX_ARGS (20)
#define MAX_JOBS 100

const std::string WHITESPACE = " \n\r\t\f\v";
std::string _ltrim(const std::string& s);
std::string _rtrim(const std::string& s);
std::string _trim(const std::string& s);
bool doesIncludeString(const std::string& cmd_line, const std::string& toFind);

class JobsList;

class Command {

private:
    static std::string removeBackgroundSign(const std::string& cmd_line);


protected:
    std::string _cmd_line;

    char** _parsed_cmd_line;
    size_t _num_words;

    static size_t countWords(const std::string& input);
    static int parseCommandLine(const std::string &cmd_line, char** args);
    pid_t _cmdPid;

public:
    explicit Command(std::string  cmd_line);
    virtual ~Command();
    virtual void execute() = 0;
    virtual void prepare();
    virtual void cleanup();
    std::string getCmdLine() const;
    pid_t* getPtrPid() { return &_cmdPid; }
};




class ExternalCommand : public Command {
private:
    JobsList* _jobs;
    bool _isBackground;
    bool _is_complex;
    pid_t* _ptrFgPid;

public:
    ExternalCommand(const std::string& cmd_line, JobsList* jobs, pid_t* ptrFgPid);
    void execute() override;
    std::string getPrettifiedParsedCmdLine() const;
    void prepare() override;
};

class JobsList {

public:
    class JobEntry {
    private:
        std::string _job_cmd_line;
        pid_t _jobPid;
        int _jobId;

        friend class JobsList;
    public:
        JobEntry(std::string  cmd_line, pid_t pid, int jobId);
        pid_t getPid() const { return _jobPid; }
        std::string getCmdLine() const { return _job_cmd_line; }
        void killJob() const;
    };


public:
    JobsList() = default;
    ~JobsList();
    void addJob(const std::string& cmd_line, pid_t pid);
    void printJobsList();
    void killAllJobs();
    void removeFinishedJobs();
    JobEntry* getJobById(int jobId);
    void removeJobById(int jobId, bool toKill = false);
    JobEntry* getJobWithMaxId(int* maxJobId);
    int size() const { return _jobs.size(); }

private:
    std::vector<JobEntry*> _jobs;
    int _maxJobId = 0;

    void findAndSetMaxJobId();
    static bool compareJobIds(JobsList::JobEntry *job1, JobsList::JobEntry *job2);
};

class BuiltInCommand : public Command {
public:
    explicit BuiltInCommand(const std::string& cmd_line) : Command(cmd_line) {}
    void printError() const;
};

class ChangeDirCommand : public BuiltInCommand {
private:
    char** _plastPwd;
public:
    ChangeDirCommand(const std::string& cmd_line, char** plastPwd) : BuiltInCommand(cmd_line), _plastPwd(plastPwd) {}
    void execute() override;
};

class GetCurrDirCommand : public BuiltInCommand {
public:
    explicit GetCurrDirCommand(const std::string& cmd_line) : BuiltInCommand(cmd_line) {}
    void execute() override;
};

class ShowPidCommand : public BuiltInCommand {
public:
    explicit ShowPidCommand(const std::string& cmd_line) : BuiltInCommand(cmd_line) {}
    void execute() override;
};


class QuitCommand : public BuiltInCommand {
private:
    JobsList* _jobs;
public:
    QuitCommand(const std::string& cmd_line, JobsList* jobs) : BuiltInCommand(cmd_line), _jobs(jobs) {}
    void execute() override;
};


class JobsCommand : public BuiltInCommand {
private:
    JobsList* _jobs;
public:
    JobsCommand(const std::string& cmd_line, JobsList* jobs) : BuiltInCommand(cmd_line), _jobs(jobs) {}
    void execute() override;
};

class KillCommand : public BuiltInCommand {
private:
    JobsList* _jobs;
public:
    KillCommand(const std::string& cmd_line, JobsList* jobs) : BuiltInCommand(cmd_line), _jobs(jobs) {}
    void execute() override;
};

class ForegroundCommand : public BuiltInCommand {
private:
    JobsList* _jobs;
    pid_t* _ptrFgPid;
public:
    ForegroundCommand(const std::string& cmd_line, JobsList* jobs, pid_t* ptrFgPid) :
            BuiltInCommand(cmd_line),
            _jobs(jobs),
            _ptrFgPid(ptrFgPid)
    {}
    void execute() override;
};

class ChmodCommand : public BuiltInCommand {
public:
    explicit ChmodCommand(const std::string& cmd_line) : BuiltInCommand(cmd_line) {}
    void execute() override;
};

class ChangePromptCommand : public BuiltInCommand {
private:
    std::string* _smash_prompt;
    static const char* SMASH_NAME;
public:
    ChangePromptCommand(const std::string& cmd_line, std::string* smash_prompt) :
            BuiltInCommand(cmd_line),
            _smash_prompt(smash_prompt)
    {}
    void execute() override;
};

class TimeoutJobsList;
class TimeoutCommand : public BuiltInCommand {
private:
    Command* _cmd;
    size_t _duration;
    TimeoutJobsList* _timeoutJobsList;
public:
    TimeoutCommand(const std::string& cmd_line, Command* cmd, size_t duration, TimeoutJobsList* timeoutJobsList) :
            BuiltInCommand(cmd_line),
            _cmd(cmd),
            _duration(duration),
            _timeoutJobsList(timeoutJobsList)
    {}
    void execute() override;
};

class PipeCommand : public Command {
private:
    Command* _firstCmd;
    Command* _secondCmd;
    bool _toStderr;


public:
    PipeCommand(const std::string& cmd_line, Command* firstCommand, Command* secondCommand, bool toStderr = false);
    ~PipeCommand() override;
    void execute() override;
    void cleanup() override;
};

class RedirectionCommand : public Command {
private:
    Command* _cmd;
    int _flags;
    std::string _file_name;

    static std::string getRedirectionFileName(const std::string& cmd_line);

public:
    RedirectionCommand(const std::string& cmd_line, Command* cmd) :
            Command(cmd_line),
            _cmd(cmd),
            _flags(doesIncludeString(
                    cmd_line, ">>") ? O_WRONLY | O_CREAT | O_APPEND : O_WRONLY | O_CREAT | O_TRUNC),
            _file_name(getRedirectionFileName(cmd_line))
    {}
    ~RedirectionCommand() override;
    void execute() override;
};


class TimeoutJobsList {
public:
    class TimeoutJobEntry {
    private:
        std::string _cmd_line;
        size_t _duration;
        pid_t* _pid;
        time_t _start_time;

        friend class TimeoutJobsList;

    public:
        TimeoutJobEntry(std::string cmd_line, size_t duration, pid_t* pid);

        int getPid() const {
//            assert(_pid != nullptr);
            return *(_pid);
        }

        void printTimeoutJob() const {
            std::cout << "smash: " << _cmd_line << " timed out!" << std::endl;
        }
    };

private:
    std::vector<TimeoutJobEntry *> _timeoutJobs;

    static bool compareTimeouts(TimeoutJobEntry *timeout1, TimeoutJobEntry *timeout2);


public:
    TimeoutJobsList() = default;

    ~TimeoutJobsList();

    void addTimeout(const std::string& cmd_line, size_t duration, Command* cmd);

    void sortTimeoutsList();

    TimeoutJobEntry* getFirstTimeoutJob() const { return _timeoutJobs[0]; }

    void removeFirstTimeoutJob();

};


class SmallShell {
private:
    std::string _prompt;
    char* _lastPwd;
    JobsList* _jobs;
    TimeoutJobsList* _timeoutJobsList;
    bool _to_quit;

    pid_t _fgPid;

    SmallShell();

    Command* CreateCommand(const std:: string& cmd_line);
    static std::string getFirstWord(const std::string& str);

    static void parsePipeCommand(const std::string &cmd_line, std::string parsedPipeCommand[]);
    static void parseTimeoutCommand(const std::string &cmd_line, std::string parsedTimeoutCommand[]);

public:

    Command* CommandFactory(const std:: string& cmd_line);
    SmallShell(SmallShell const&)      = delete; // disable copy ctor
    void operator=(SmallShell const&)  = delete; // disable = operator
    static SmallShell& getInstance() // make SmallShell singleton
    {
        static SmallShell instance; // Guaranteed to be destroyed.
        // Instantiated on first use.
        return instance;
    }
    ~SmallShell();
    void executeCommand(const std:: string& cmd_line);
    std::string getPrompt() const;
    bool toQuit() const;
    TimeoutJobsList* getTimeoutJobsList() const { return _timeoutJobsList; }
    pid_t* getFgPid() { return &_fgPid; }
    void setFgPid(pid_t pid) { _fgPid = pid; }
};


#endif //SMASH_COMMAND_H_
