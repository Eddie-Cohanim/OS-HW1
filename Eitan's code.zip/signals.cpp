#include <iostream>
#include <signal.h>
#include "signals.h"
#include "Commands.h"
#include "sys/wait.h"

using namespace std;

class SmallShell;

void ctrlCHandler(int sig_num) {
    cout << "smash: got ctrl-C" << endl;
    SmallShell& smash = SmallShell::getInstance();
    pid_t fgPid = *(smash.getFgPid());

    if (fgPid != -1) {
        if (kill(fgPid, SIGKILL) == -1) {
            perror("smash error: kill failed");
            return;
        }
        std::cout << "smash: process " << fgPid << " was killed" << std::endl;
        smash.setFgPid(-1);
    }
}

void alarmHandler(int sig_num) {

    cout << "smash: got an alarm" << endl;
    SmallShell& smash = SmallShell::getInstance();
    TimeoutJobsList* timeoutJobsList = smash.getTimeoutJobsList();
    TimeoutJobsList::TimeoutJobEntry* timeoutJobEntry = timeoutJobsList->getFirstTimeoutJob();
    pid_t pid = timeoutJobEntry->getPid();

    if (waitpid(pid, nullptr, WNOHANG) != 0) {
        timeoutJobsList->removeFirstTimeoutJob();
        return;
    }

    if (kill(pid, SIGKILL) == -1) {
        perror("smash error: kill failed");
        return;
    }
    timeoutJobEntry->printTimeoutJob();
    timeoutJobsList->removeFirstTimeoutJob();
}

