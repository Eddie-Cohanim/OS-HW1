#include "Commands.h"
#include <sstream>
#include <sys/stat.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>
#include <cstring>
#include <algorithm>

using namespace std;

#if 0
#define FUNC_ENTRY()  \
  cout << __PRETTY_FUNCTION__ << " --> " << endl;

#define FUNC_EXIT()  \
  cout << __PRETTY_FUNCTION__ << " <-- " << endl;
#else
#define FUNC_ENTRY()
#define FUNC_EXIT()
#endif


string _ltrim(const std::string& s)
{
    size_t start = s.find_first_not_of(WHITESPACE);
    return (start == std::string::npos) ? "" : s.substr(start);
}

string _rtrim(const std::string& s)
{
    size_t end = s.find_last_not_of(WHITESPACE);
    return (end == std::string::npos) ? "" : s.substr(0, end + 1);
}

string _trim(const std::string& s)
{
    return _rtrim(_ltrim(s));
}

bool doesIncludeString(const std::string& cmd_line, const std::string& toFind) {
    return cmd_line.find(toFind) != string::npos;
}


Command::Command(std::string cmd_line) :
        _cmd_line(std::move(cmd_line)),

        _parsed_cmd_line(nullptr),
        _num_words(0),
        _cmdPid(0)
{
    prepare();
}

Command::~Command() {
    cleanup();
}


void Command::prepare() {
//    assert(_cmd_line.length() <= COMMAND_ARGS_MAX_LENGTH);

    string modified_cmd_line = removeBackgroundSign(_cmd_line);
    size_t numWords = countWords(modified_cmd_line);
    _parsed_cmd_line = new char* [numWords + 1];
    _num_words = parseCommandLine(modified_cmd_line, _parsed_cmd_line);
//    assert(_num_words == numWords);
//    assert(_num_words <= COMMAND_MAX_ARGS);
}

void Command::cleanup() {
    for (size_t i = 0; i < _num_words; ++i) {
        free(_parsed_cmd_line[i]);
    }
    delete[] _parsed_cmd_line;
    _parsed_cmd_line = nullptr;
    _num_words = 0;
}

std::string Command::removeBackgroundSign(const string &cmd_line) {
    string str(cmd_line);
    // find last character other than spaces
    size_t idx = str.find_last_not_of(WHITESPACE);

    if (idx == string::npos) {
        return str;
    }
    // if the command line does not end with & then return
    if (str[idx] != '&') {
        return str;
    }
    // replace the & (background sign) with space and then remove all tailing spaces.
    str[idx] = ' ';
    // truncate the command line string up to the last non-space character
    return str.substr(0, str.find_last_not_of(WHITESPACE, idx) + 1);
}

size_t Command::countWords(const string &input) {
    std::istringstream ss(input);
    std::string word;
    size_t wordCount = 0;

    while (ss >> word) {
        wordCount++;
    }

    return wordCount;
}

int Command::parseCommandLine(const string &cmd_line, char **args) {
    FUNC_ENTRY()

    int i = 0;
    std::istringstream iss(_trim(cmd_line));

    for(std::string s; iss >> s; ) {

        args[i] = (char*)malloc(s.length()+1);
        memset(args[i], 0, s.length()+1);
        strcpy(args[i], s.c_str());
        args[++i] = nullptr;
    }
    return i;

    FUNC_EXIT()
}

std::string Command::getCmdLine() const {
    return _cmd_line;
}


void BuiltInCommand::printError() const {
    cout << "smash error:> \"" << _cmd_line << "\"" << endl;
}

const char* ChangePromptCommand::SMASH_NAME = "smash";
void ChangePromptCommand::execute() {
    if (_num_words == 1) {
        *(_smash_prompt) = SMASH_NAME;
        return;
    }
    *(_smash_prompt) = _parsed_cmd_line[1];
}

void ShowPidCommand::execute() {
    int pid = getpid();
    if (pid == -1) {
        perror("smash error: getpid failed");
        return;
    }
    cout << "smash pid is " << pid << endl;
}

void GetCurrDirCommand::execute() {
    const char* cwd = getcwd(nullptr, 0);
    if (cwd == nullptr) {
        perror("smash error: getcwd failed");
        return;
    }
    cout << cwd << endl;
    delete cwd;
}

void ChangeDirCommand::execute() {
//    assert(_num_words != 1);

    if (_num_words == 2) {
        char* lastPwd = getcwd(nullptr, 0);
        if (lastPwd == nullptr) {
            perror("smash error: getcwd failed");
            return;
        }


        if (strcmp(_parsed_cmd_line[1], "-") == 0) {
            if (*(_plastPwd) == nullptr) {
                cerr << "smash error: cd: OLDPWD not set" << endl;
                delete lastPwd;
                return;
            }

            if (chdir(*(_plastPwd)) == -1) {
                perror("smash error: chdir failed");
                delete lastPwd;
                return;
            }
        }

        else if (chdir(_parsed_cmd_line[1]) == -1) {
            perror("smash error: chdir failed");
            delete lastPwd;
            return;
        }

        if (*(_plastPwd) != nullptr) {
            delete *(_plastPwd);
        }

        *(_plastPwd) = lastPwd;
        return;
    }
    cerr << "smash error: cd: too many arguments" << endl;
}

void JobsCommand::execute() {
    _jobs->printJobsList();
}

void ForegroundCommand::execute() {


    JobsList::JobEntry* job;
    int job_id;
    if (_num_words == 1) {
        job = _jobs->getJobWithMaxId(&job_id);
        if (job == nullptr) {
            cerr << "smash error: fg: jobs list is empty" << endl;
            return;
        }
    }
    else {
        char* endPtr;
        job_id = strtol(_parsed_cmd_line[1], &endPtr, 10);
        if (*endPtr != '\0') {
            cerr << "smash error: fg: invalid arguments" << endl;
            return;
        }

        job = _jobs->getJobById(job_id);
        if (job == nullptr) {
            cerr << "smash error: fg: job-id " << _parsed_cmd_line[1] << " does not exist" << endl;
            return;
        }
    }

    if (_num_words > 2) {
        cerr << "smash error: fg: invalid arguments" << endl;
        return;
    }

    int pid = job->getPid();
    *(_ptrFgPid) = pid;

    cout << job->getCmdLine() << " " << pid << endl;
    _jobs->removeJobById(job_id, false);
    if (waitpid(pid, nullptr, 0) == -1) {
        perror("smash error: waitpid failed");
        *(_ptrFgPid) = -1;
        return;
    }
    *(_ptrFgPid) = -1;
}

void QuitCommand::execute() {
    if (_num_words >= 2) {
        if (strcmp(_parsed_cmd_line[1], "kill") == 0) {
            cout << "smash: sending SIGKILL signal to " << _jobs->size() << " jobs:" << endl;
            _jobs->killAllJobs();
        }
    }
}

void KillCommand::execute() {

    if (_num_words < 3) {
        cerr << "smash error: kill: invalid arguments" << endl;
        return;
    }

    char* endPtr;
    int job_id = strtol(_parsed_cmd_line[2], &endPtr, 10);
    if (*endPtr != '\0') {
        cerr << "smash error: kill: invalid arguments" << endl;
        return;
    }


    JobsList::JobEntry* job = _jobs->getJobById(job_id);
    if (job == nullptr) {
        cerr << "smash error: kill: job-id " << _parsed_cmd_line[2] << " does not exist" << endl;
        return;
    }

    if (_parsed_cmd_line[1][0] != '-') {
        cerr << "smash error: kill: invalid arguments" << endl;
        return;
    }

    int signal = strtol(_parsed_cmd_line[1] + 1, &endPtr, 10);

    if (*endPtr != '\0') {
        cerr << "smash error: kill: invalid arguments" << endl;
        return;
    }

    if (_num_words > 3) {
        cerr << "smash error: kill: invalid arguments" << endl;
        return;
    }

    int pid = job->getPid();

    if (kill(pid, signal) == -1) {
        perror("smash error: kill failed");
        return;
    }

    if (signal == SIGKILL) {
        _jobs->removeJobById(job_id, true);
    }

    cout << "signal number " << signal << " was sent to pid " << pid << endl;
}

void ChmodCommand::execute() {
    if (_num_words != 3) {
        cerr << "smash error: chmod: invalid arguments" << endl;
        return;
    }

    // Check if the length of the mode is exactly 3 digits
    if (strlen(_parsed_cmd_line[1]) != 3) {
        cerr << "smash error: chmod: invalid arguments" << endl;
        return;
    }

    char* endPtr;
    int mode = strtol(_parsed_cmd_line[1], &endPtr, 8);
    // Check if strtol encountered an error (e.g., non-numeric characters)
    if (*endPtr != '\0') {
        cerr << "smash error: chmod: invalid arguments" << endl;
        return;
    }

    if (mode < 0 || mode > 0777) {
        cerr << "smash error: chmod: invalid arguments" << endl;
        return;
    }

    if (chmod(_parsed_cmd_line[2], mode) == -1) {
        perror("smash error: chmod failed");
        return;
    }
}

void TimeoutCommand::execute() {
    _timeoutJobsList->addTimeout(_cmd->getCmdLine(), _duration, _cmd);
}


ExternalCommand::ExternalCommand(const std::string& cmd_line, JobsList *jobs, pid_t* ptrFgPid) :
        Command(cmd_line),
        _jobs(jobs),
        _isBackground(_cmd_line[_cmd_line.find_last_not_of(WHITESPACE)] == '&'),
        _is_complex(cmd_line.find_first_of("?*") != string::npos),
        _ptrFgPid(ptrFgPid)

{
    prepare();
}

void ExternalCommand::prepare() {

    if (_is_complex) {
        string prettifiedParsedCmdLine = getPrettifiedParsedCmdLine();
        cleanup();
        _parsed_cmd_line = new char *[4];
        char* bash_str = strdup("bash");
        char* complex_cmd = strdup("-c");
        _parsed_cmd_line[0] = bash_str;
        _parsed_cmd_line[1] = complex_cmd;
        _parsed_cmd_line[2] = strdup(prettifiedParsedCmdLine.c_str());
        _parsed_cmd_line[3] = nullptr;
        _num_words = 3;
    }
}


std::string ExternalCommand::getPrettifiedParsedCmdLine() const {
    std::string pretty_cmd_line;
    for (size_t i = 0; i < _num_words; ++i) {
        pretty_cmd_line += " ";
        pretty_cmd_line += _parsed_cmd_line[i];
    }

    if (_isBackground) {
        pretty_cmd_line += "&";
    }
    return pretty_cmd_line;
}


void ExternalCommand::execute() {
    pid_t pid = fork();
    if (pid == -1) {
        perror("smash error: fork failed");
        return;
    }
    if (pid == 0) {
        _jobs->removeFinishedJobs();
        setpgrp();

        if (execvp(_parsed_cmd_line[0], _parsed_cmd_line) == -1) {
            perror("smash error: execvp failed");
            exit(EXIT_FAILURE);
        }
    }
//    assert(pid > 0);
    _cmdPid = pid;

    if (!_isBackground) {
        *_ptrFgPid = pid;
        int status;
        if (waitpid(pid, &status, 0) == -1) {
            perror("smash error: waitpid failed");
            *(_ptrFgPid) = -1;
            return;
        }
        *(_ptrFgPid) = -1;
    } else {
        _jobs->addJob(_cmd_line, pid);
    }
}


void JobsList::addJob(const std::string& cmd_line, pid_t pid) {
    removeFinishedJobs();
//    assert(_jobs.size() + 1 <= MAX_JOBS);
    _jobs.push_back(new JobEntry(cmd_line, pid, int(++_maxJobId)));
}

void JobsList::printJobsList() {
    removeFinishedJobs();

    sort(_jobs.begin(), _jobs.end(), compareJobIds);
    for (auto &job : _jobs) {
        cout << "[" << job->_jobId << "] " << job->_job_cmd_line << endl;
    }
}

void JobsList::killAllJobs() {
    for (auto &job : _jobs) {
        cout << job->_jobPid << ": " << job->_job_cmd_line << endl;
        job->killJob();
    }
}

void JobsList::removeFinishedJobs() {
    for (auto it = _jobs.begin(); it != _jobs.end();) {
        int status;
        if (waitpid((*it)->_jobPid, &status, WNOHANG) != 0) {
            delete *it;
            it = _jobs.erase(it);
        } else {
            ++it;
        }
    }
    findAndSetMaxJobId();
}

JobsList::JobEntry *JobsList::getJobById(int jobId) {
    for (auto &job : _jobs) {
        if (job->_jobId == jobId) {
            return job;
        }
    }
    return nullptr;
}

void JobsList::removeJobById(int jobId, bool toKill) {
    for (auto it = _jobs.begin(); it != _jobs.end(); ++it) {
        if ((*it)->_jobId == jobId) {
            if (toKill) {
                (*it)->killJob();
            }
            delete *it;
            _jobs.erase(it);
            return;
        }
    }
    findAndSetMaxJobId();
}

void JobsList::JobEntry::killJob() const {
    if (kill(_jobPid, SIGKILL) == -1) {
        perror("smash error: kill failed");
    }
}

JobsList::~JobsList() {
    for (auto &job : _jobs) {
        delete job;
    }
}

void JobsList::findAndSetMaxJobId() {
    _maxJobId = 0;
    for (auto &job : _jobs) {
        if (job->_jobId > _maxJobId) {
            _maxJobId = job->_jobId;
        }
    }
}

// Custom comparison function for sorting jobs based on job-id
bool JobsList::compareJobIds(JobsList::JobEntry *job1, JobsList::JobEntry *job2) {
    return job1->_jobId < job2->_jobId;
}

JobsList::JobEntry *JobsList::getJobWithMaxId(int *maxJobId) {
    if (_jobs.empty()) {
        return nullptr;
    }
    // Use std::max_element with the compareJobIds function to find the maximum job-id
    auto maxJobEntry = std::max_element(_jobs.begin(), _jobs.end(), compareJobIds);
    *maxJobId = (*maxJobEntry)->_jobId;
    return *maxJobEntry;
}

JobsList::JobEntry::JobEntry(std::string  cmd_line, pid_t pid, int jobId) :
        _job_cmd_line(std::move(cmd_line)),
        _jobPid(pid),
        _jobId(jobId)
{}


PipeCommand::PipeCommand(const std::string &cmd_line, Command* firstCommand, Command* secondCommand, bool toStderr) :
        Command(cmd_line),
        _firstCmd(firstCommand),
        _secondCmd(secondCommand),
        _toStderr(toStderr)
{}

void PipeCommand::cleanup() {
    delete _firstCmd;
    delete _secondCmd;
}

PipeCommand::~PipeCommand() {
    cleanup();
}

void PipeCommand::execute() {
    int pipefd[2];
    int writeEnd = _toStderr ? STDERR_FILENO : STDOUT_FILENO;
    if (pipe(pipefd) == -1) {
        perror("smash error: pipe failed");
        return;
    }
    pid_t firstPid = fork();
    if (firstPid == -1) {
        perror("smash error: fork failed");
        return;
    }
    if (firstPid == 0) {
        close(pipefd[0]);
        if (dup2(pipefd[1], writeEnd) == -1) {
            perror("smash error: dup2 failed");
            return;
        }
        close(pipefd[1]);
        _firstCmd->execute();
        exit(0);
    }
    pid_t secondPid = fork();
    if (secondPid == -1) {
        perror("smash error: fork failed");
        return;
    }
    if (secondPid == 0) {
        close(pipefd[1]);
        if (dup2(pipefd[0], STDIN_FILENO) == -1) {
            perror("smash error: dup2 failed");
            return;
        }
        close(pipefd[0]);
        _secondCmd->execute();
        exit(0);
    }
    close(pipefd[0]);
    close(pipefd[1]);
    int status;
    if (waitpid(firstPid, &status, 0) == -1) {
        perror("smash error: waitpid failed");
        return;
    }
    if (waitpid(secondPid, &status, 0) == -1) {
        perror("smash error: waitpid failed");
        return;
    }
}


RedirectionCommand::~RedirectionCommand() {
    delete _cmd;
}

void RedirectionCommand::execute() {
//    assert(!isBackgroundCommand(_cmd_line));
//    assert(_cmd != nullptr);
//    assert(_cmd_line != "");

    int fd = open(_file_name.c_str(), _flags, 0666);
    if (fd == -1) {
        perror("smash error: open failed");
        return;
    }

    int stdout_fd = dup(STDOUT_FILENO);
    if (stdout_fd == -1) {
        perror("smash error: dup failed");
        return;
    }
    if (dup2(fd, STDOUT_FILENO) == -1) {
        perror("smash error: dup2 failed");
        return;
    }
    _cmd->execute();
    if (dup2(stdout_fd, STDOUT_FILENO) == -1) {
        perror("smash error: dup2 failed");
        return;
    }
    if (close(fd) == -1) {
        perror("smash error: close failed");
        return;
    }
    if (close(stdout_fd) == -1) {
        perror("smash error: close failed");
        return;
    }
}

std::string RedirectionCommand::getRedirectionFileName(const std::string &cmd_line) {
    size_t idx = cmd_line.find_last_of('>');
//    assert(idx != std::string::npos);
    return _trim(cmd_line.substr(idx + 1));
}


TimeoutJobsList::~TimeoutJobsList() {
    for (auto &timeout : _timeoutJobs) {
        delete timeout;
    }
}

void TimeoutJobsList::addTimeout(const std::string& cmd_line, size_t duration, Command* cmd) {

    _timeoutJobs.push_back(new TimeoutJobEntry(cmd_line, duration, cmd->getPtrPid()));

    if (_timeoutJobs.size() == 1) {
        alarm(duration);
    }

    else if (_timeoutJobs[0]->_start_time + _timeoutJobs[0]->_duration > _timeoutJobs.back()->_start_time + _timeoutJobs.back()->_duration) {
        alarm(duration);
    }

    sortTimeoutsList();

    cmd->execute();
}

void TimeoutJobsList::sortTimeoutsList() {
    std::sort(_timeoutJobs.begin(), _timeoutJobs.end(), compareTimeouts);
}

bool TimeoutJobsList::compareTimeouts(TimeoutJobsList::TimeoutJobEntry *timeout1, TimeoutJobsList::TimeoutJobEntry *timeout2) {
    return timeout1->_start_time + timeout1->_duration < timeout2->_start_time + timeout2->_duration;
}

void TimeoutJobsList::removeFirstTimeoutJob() {
    TimeoutJobEntry* first = _timeoutJobs[0];
    _timeoutJobs.erase(_timeoutJobs.begin());

    if (!_timeoutJobs.empty()) {
        size_t new_duration = _timeoutJobs[0]->_duration + _timeoutJobs[0]->_start_time - first->_duration - first->_start_time;
        alarm(new_duration);
    }

    delete first;
}


TimeoutJobsList::TimeoutJobEntry::TimeoutJobEntry(std::string cmd_line, size_t duration, pid_t* pid) :
        _cmd_line(std::move(cmd_line)),
        _duration(duration),
        _pid(pid),
        _start_time(time(nullptr))
{}


SmallShell::SmallShell() :
        _prompt("smash"),
        _lastPwd(nullptr),
        _jobs(new JobsList()),
        _timeoutJobsList(new TimeoutJobsList()),
        _to_quit(false),
        _fgPid(-1)
{}

SmallShell::~SmallShell() {
    delete _jobs;
    delete _timeoutJobsList;
    delete _lastPwd;

}

void SmallShell::parsePipeCommand(const string &cmd_line, std::string parsedPipeCommand[]) {
    size_t pipePos = cmd_line.find('|');
//    assert(pipePos != string::npos);
    parsedPipeCommand[0] = _trim(cmd_line.substr(0, pipePos));
    parsedPipeCommand[1] = (cmd_line.find("|&", pipePos) != string::npos) ? "|&" : "|";
    parsedPipeCommand[2] = _trim(cmd_line.substr(pipePos + parsedPipeCommand[1].length()));
}

void SmallShell::parseTimeoutCommand(const string &cmd_line, std::string *parsedTimeoutCommand) {
    string timeout_str = "timeout";
    size_t timeoutPos = cmd_line.find(timeout_str);
//    assert(timeoutPos != string::npos);
    size_t length = timeoutPos + timeout_str.length();
    parsedTimeoutCommand[0] = _trim(cmd_line.substr(0, timeoutPos + length));

    length = parsedTimeoutCommand[0].length();
    parsedTimeoutCommand[1] = _trim(cmd_line.substr(timeoutPos + length, cmd_line.find_first_of(" \n", timeoutPos + length + 1) - length));

    length += parsedTimeoutCommand[1].length();
    parsedTimeoutCommand[2] = _trim(cmd_line.substr(timeoutPos + length + 1));
}

Command * SmallShell::CommandFactory(const std:: string& cmd_line) {
    _fgPid = -1;
    bool isRedirection = doesIncludeString(cmd_line, ">");
    bool isPipe = doesIncludeString(cmd_line, "|");
    bool isTimeout = doesIncludeString(cmd_line, "timeout");
//    assert((isRedirection && isPipe) == false);
    if (isRedirection){
        string modifiedCmdLine = cmd_line.substr(0, cmd_line.find_last_of('>'));
        Command* cmd = CreateCommand(modifiedCmdLine);
        return new RedirectionCommand(cmd_line, cmd);
    }

    else if (isPipe) {
        string parsedPipeCommand[3];
        parsePipeCommand(cmd_line, parsedPipeCommand);
        Command* firstCmd = CreateCommand(parsedPipeCommand[0]);
        Command* secondCmd = CreateCommand(parsedPipeCommand[2]);
        return new PipeCommand(cmd_line, firstCmd, secondCmd, parsedPipeCommand[1] == "|&");
    }

    else if (isTimeout) {
        string paredTimeoutCommand[3];
        parseTimeoutCommand(cmd_line, paredTimeoutCommand);
        size_t duration = strtol(paredTimeoutCommand[1].c_str(), nullptr, 10);
        Command* cmd = CreateCommand(paredTimeoutCommand[2]);
        return new TimeoutCommand(cmd_line, cmd, duration, _timeoutJobsList);
    }

    return CreateCommand(cmd_line);
}


/**
* Creates and returns a pointer to Command class which matches the given command line (cmd_line)
*/
Command * SmallShell::CreateCommand(const std::string& cmd_line) {

    string firstWord = getFirstWord(cmd_line);

    if (firstWord.empty()) {
        return nullptr;
    }

    if (firstWord == "pwd") {
        return new GetCurrDirCommand(cmd_line);
    }

    else if (firstWord == "showpid") {
        return new ShowPidCommand(cmd_line);
    }

    else if (firstWord == "chprompt") {
        return new ChangePromptCommand(cmd_line, &_prompt);
    }

    else if (firstWord == "quit") {
        return new QuitCommand(cmd_line, _jobs);
    }

    else if (firstWord == "cd") {
        return new ChangeDirCommand(cmd_line, &_lastPwd);
    }

    else if (firstWord == "jobs") {
        return new JobsCommand(cmd_line, _jobs);
    }

    else if (firstWord == "kill") {
        return new KillCommand(cmd_line, _jobs);
    }

    else if (firstWord == "fg") {
        return new ForegroundCommand(cmd_line, _jobs, &_fgPid);
    }

    else if (firstWord == "chmod") {
        return new ChmodCommand(cmd_line);
    }

    else {
        return new ExternalCommand(cmd_line, _jobs, &_fgPid);
    }
}

void SmallShell::executeCommand(const std:: string& cmd_line) {
    _jobs->removeFinishedJobs();
    Command* cmd = CommandFactory(cmd_line);

    if (cmd == nullptr) {
        return;
    }

    cmd->execute();

    bool isQuitCommand = (dynamic_cast<QuitCommand*>(cmd) != nullptr);
    _to_quit = isQuitCommand;
    delete cmd;
}

std::string SmallShell::getPrompt() const {
    return _prompt;
}

std::string SmallShell::getFirstWord(const string &str) {
    string str_s = _trim(str);

    return str_s.substr(0, str_s.find_first_of(" \n>&"));
}

bool SmallShell::toQuit() const {
    return _to_quit;
}
